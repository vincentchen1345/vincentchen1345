function(){
	var name = document.getElementById('username');
	var age = document.getElementById('age');
	var email = document.getElementById('email');
	if (name==''||email''||age''){
		alert('required');
		return false;
	}else{
		return true;
	}
}