//anonymous function
$(function(){
    let width = 720
    let speed = 1000 //ms
    let pause = 3000
    let currSlide = 1

    let $slideContainer = $('.slides')

    let interval
    
    startSlider()

    $('#backBtn').click(function(){
        clearInterval(interval)

        if(currSlide == 1){
        
            $slideContainer.animate({'margin-left': '-=' + 2*width},speed ,function(){currSlide = 3 })
        }else{
            
        $slideContainer.animate({'margin-left': '+=' + width},speed ,function(){currSlide --})
        }
         startSlider()
    })
    $('#forwardBtn').click(function(){
        clearInterval(interval)
        $slideContainer.animate({'margin-left': '-=' + width},speed ,function(){currSlide ++})
        startSlider()
    })

    //setInterval (function yang dijalanin, pause) setiap brp detik function dijalanin
    function startSlider() {
        //css
        //speed
        //callback function
        //setelah animate dipanggil callback function baru jalan
       // $slideContainer.animate({'margin-left': '-=' + width},speed ,function(){}) //dikurangi sebanyak
       interval =  setInterval(function(){ $slideContainer.animate({'margin-left': '-=' + width},speed ,function(){
                     currSlide ++
                     if(currSlide > 3) {
                     currSlide = 1
                     $slideContainer.css ('margin-left',0)
            }
       })},pause)
    }
})