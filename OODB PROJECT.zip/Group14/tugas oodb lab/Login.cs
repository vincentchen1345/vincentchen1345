﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_OODB_Vincent
{
    public partial class Login : Form
    {
        databaseLaptopEntities db = new databaseLaptopEntities();
        mainPage mainPage;
        mainPageForStaff mainPageS;
        registerPage register;
        public static string userID = "";
        public static string username = "";
        public Login()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            username = UsernameTextBox.Text;
            
            if(username == "")
            {
                MessageBox.Show("Username must be filled!");
                return;
            }
                else if(PasswordTextBox.Text == "")
                {
                    MessageBox.Show("Password must be filled!");
                    return;
                }
            var check = (from x in db.Users where x.UserName.Equals(username) && x.UserPassword.Equals(PasswordTextBox.Text) select x).FirstOrDefault();
            
            try
            {
                if(PasswordTextBox.Text == check.UserPassword&&
                    username == check.UserName)
                {
                    if(check.UserRole=="User")
                    {
                        mainPage = new mainPage();
                        mainPage.Show();
                        this.Hide();
                        
                    }
                    else
                    {
                        mainPageS = new mainPageForStaff();
                        mainPageS.Show();
                        this.Hide();
                    }
                    userID = check.UserID;
                }
            }
            catch
            {
                MessageBox.Show("Invalid Username or Password!");
            }
        }

        private void RegisterLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            register = new registerPage();
            register.Show();
            this.Hide();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
