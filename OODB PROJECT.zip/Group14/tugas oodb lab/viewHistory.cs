﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_OODB_Vincent
{
    public partial class viewHistory : Form
    {
        databaseLaptopEntities db = new databaseLaptopEntities();
        public viewHistory()
        {
            InitializeComponent();
            insertList();
        }
        public void insertList()
        {
            var items = new[]
            {
                new { Text = "Januari", Value = "01" },
                new { Text = "Februari", Value = "02" },
                new { Text = "Maret", Value = "03" },
                new { Text = "April", Value = "04" },
                new { Text = "Mei", Value = "05" },
                new { Text = "Juni", Value = "06" },
                new { Text = "Juli", Value = "07" },
                new { Text = "Agustus", Value = "08" },
                new { Text = "September", Value = "09" },
                new { Text = "Oktober", Value = "10" },
                new { Text = "November", Value = "11" },
                new { Text = "Desember", Value = "12" }
            };

            comboBox1.DataSource = items;
            comboBox1.DisplayMember = "Text";
            comboBox1.ValueMember = "Value";
            viewData();
        }
        public void viewData()
        {
            string userID = Login.userID;
            var query = (from x in db.HeaderTransactions where x.UserID.Equals(userID) select x).ToList();
            dataGridView1.DataSource = query;
        }

        public void viewDataD(string Header)
        {
            var query = (from x in db.DetailTransactions where x.TransactionID == Header select x).ToList();
            dataGridView2.DataSource = query;
        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            var a = (from x in db.HeaderTransactions where x.TransactionDate.Substring(3, 2) == comboBox1.SelectedValue.ToString() select x).ToList();
            dataGridView1.DataSource = a;
            dataGridView2.DataSource = "";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            string Header = dataGridView1.Rows[index].Cells[0].Value.ToString();
            viewDataD(Header);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            viewData();
            dataGridView2.DataSource = "";  
        }
    }
}
