﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_OODB_Vincent
{
    public partial class manageUser : Form
    {
        databaseLaptopEntities db = new databaseLaptopEntities();
        string gender = "";
        public manageUser()
        {
            InitializeComponent();
            initialState();
        }
        public void viewData()
        {
            var query = (from x in db.Users select x);
            dataGridView1.DataSource = query.ToList();
        }
        public void initialState()
        {
            viewData();
            userIdTextbox.Text = "";
            usernameTextbox.Text = "";
            emailTextbox.Text = "";
            phoneTextbox.Text = "";
            passwordTextbox.Text = "";
            richTextBox1.Text = "";
            userIdTextbox.Enabled = false;
            usernameTextbox.Enabled = false;
            emailTextbox.Enabled = false;
            phoneTextbox.Enabled = false;
            passwordTextbox.Enabled = false;
            maleRadioButton.Enabled = false;
            femaleRadioButton.Enabled = false;
            dateTimePicker1.Enabled = false;
            richTextBox1.Enabled = false;
            comboBox1.Enabled = false;
            maleRadioButton.Checked = false;
            femaleRadioButton.Checked = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button3.Enabled = true;
            button2.Enabled = true;
            button1.Enabled = true;
            dateTimePicker1.Value = DateTime.Now;

            var items = new[]
            {
                new {Text = "Admin", Value = "Admin"},
                new {Text = "User", Value = "User"},
            };


            comboBox1.DataSource = items;
            comboBox1.ValueMember = "Value";
            comboBox1.DisplayMember = "Text";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
                int index = e.RowIndex;
                userIdTextbox.Text = dataGridView1.Rows[index].Cells[0].Value.ToString();
                usernameTextbox.Text = dataGridView1.Rows[index].Cells[1].Value.ToString();
                emailTextbox.Text = dataGridView1.Rows[index].Cells[3].Value.ToString();
                phoneTextbox.Text = dataGridView1.Rows[index].Cells[5].Value.ToString();
                passwordTextbox.Text = dataGridView1.Rows[index].Cells[7].Value.ToString();
                richTextBox1.Text = dataGridView1.Rows[index].Cells[6].Value.ToString();
                if (dataGridView1.Rows[index].Cells[2].Value.ToString() == "Male")
                {
                    maleRadioButton.Checked = true;
                }
                if (dataGridView1.Rows[index].Cells[2].Value.ToString() == "Female")
                {
                    femaleRadioButton.Checked = true;
                }
                dateTimePicker1.Value = DateTime.Parse(dataGridView1.Rows[index].Cells[4].Value.ToString());
                comboBox1.SelectedValue = dataGridView1.Rows[index].Cells[8].Value.ToString();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int counter = db.Users.Count() + 1;
            string idNumber = counter.ToString("000");
            string ID = "US" + idNumber;
            initialState();

            usernameTextbox.Enabled = true;
            emailTextbox.Enabled = true;
            phoneTextbox.Enabled = true;
            passwordTextbox.Enabled = true;
            maleRadioButton.Enabled = true;
            femaleRadioButton.Enabled = true;
            dateTimePicker1.Enabled = true;
            richTextBox1.Enabled = true;
            comboBox1.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            userIdTextbox.Text = ID;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (usernameTextbox.Text == "")
            {
                MessageBox.Show("No User Selected");
                return;
            }
            else
            {
                usernameTextbox.Enabled = true;
                emailTextbox.Enabled = true;
                phoneTextbox.Enabled = true;
                passwordTextbox.Enabled = true;
                maleRadioButton.Enabled = true;
                femaleRadioButton.Enabled = true;
                dateTimePicker1.Enabled = true;
                richTextBox1.Enabled = true;
                comboBox1.Enabled = true;
                button4.Enabled = true;
                button5.Enabled = true;
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
            }
        }

        public void updateUser()
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (userIdTextbox.Text == "")
            {
                MessageBox.Show("No User Selected");
                return;
            }
            else
            {
                if (MessageBox.Show("Do you want to delete this data?", "Delete Item?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    var del = (from x in db.Users where x.UserID.Equals(userIdTextbox.Text) select x).FirstOrDefault();
                    db.Users.Remove(del);
                    db.SaveChanges();
                    viewData();
                    initialState();
                }
                else
                {
                    initialState();
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (usernameTextbox.Text == "")
            {
                MessageBox.Show("Username must be filled!");
                return;
            }
            var check = (from b in db.Users where b.UserName.Equals(usernameTextbox.Text) select b).FirstOrDefault();
            var update = (from x in db.Users where x.UserID.Equals(userIdTextbox.Text) select x).FirstOrDefault();
            try
            {
                
                update.UserName = usernameTextbox.Text;
                update.UserPassword = passwordTextbox.Text;
                update.UserAddress = richTextBox1.Text;
                update.UserDoB = dateTimePicker1.Value;
                update.UserEmail = emailTextbox.Text;
                update.UserPhone = phoneTextbox.Text;
                update.UserGender = gender;
                update.UserRole = comboBox1.SelectedValue.ToString();
                db.SaveChanges();
                MessageBox.Show("Data inserted/updated successfully!");
                viewData();
                initialState();
                
            }
            catch
            {
                try
                {
                    if (usernameTextbox.Text == check.UserName && userIdTextbox.Text != check.UserID)
                    {
                        MessageBox.Show("Username already exist");

                    }
                }
                catch
                {

                    if (emailTextbox.Text == "")
                    {
                        MessageBox.Show("Email must be filled!");
                        return;
                    }
                    if (!emailTextbox.Text.Contains('@') || !emailTextbox.Text.Contains('.'))
                    {
                        MessageBox.Show("Email must contain ‘@’ and ‘.’");
                        return;
                    }
                    if (emailTextbox.Text.ToCharArray()[0] == '@' || emailTextbox.Text.ToCharArray()[0] == '.')
                    {
                        MessageBox.Show("Email cannot start with ‘@’ or ‘.’");
                        return;
                    }
                    if (emailTextbox.Text.ToCharArray()[emailTextbox.TextLength - 1] == '@' || emailTextbox.Text.ToCharArray()[emailTextbox.TextLength - 1] == '.')
                    {
                        MessageBox.Show("Email cannot end with ‘@’ or ‘.’");
                        return;
                    }
                    int x = emailTextbox.Text.IndexOf('@');
                    if (emailTextbox.Text.ToCharArray()[x + 1] == '.')
                    {
                        MessageBox.Show("’@’ and ‘.’ cannot be placed beside each other");
                        return;
                    }
                    if (maleRadioButton.Checked != true && femaleRadioButton.Checked != true)
                    {
                        MessageBox.Show("Gender must be chosen!");
                        return;
                    }
                    if (dateTimePicker1.Value > DateTime.Today)
                    {
                        MessageBox.Show("DOB cannot be greater than current date!");
                        return;
                    }
                    if (phoneTextbox.Text == "")
                    {
                        MessageBox.Show("Phone must be filled!");
                        return;
                    }
                    if (!phoneTextbox.Text.All(char.IsDigit))
                    {
                        MessageBox.Show("Phone must be numeric!");
                        return;
                    }
                    if (phoneTextbox.Text.Length < 12)
                    {
                        MessageBox.Show("Phone must be 12 digits");
                        return;
                    }
                    if (richTextBox1.Text == "")
                    {
                        MessageBox.Show("Address must be filled!");
                        return;
                    }
                    if (!richTextBox1.Text.Contains("Street"))
                    {
                        MessageBox.Show("Address must contain ‘Street’");
                        return;
                    }
                    if (passwordTextbox.Text == "")
                    {
                        MessageBox.Show("Password must be filled!");
                        return;
                    }
                    if (passwordTextbox.Text.Length < 5)
                    {
                        MessageBox.Show("Password length must be 5 characters or more");
                        return;
                    }


                    User user = new User();
                    user.UserID = userIdTextbox.Text;
                    user.UserName = usernameTextbox.Text;
                    user.UserPassword = passwordTextbox.Text;
                    user.UserAddress = richTextBox1.Text;
                    user.UserDoB = dateTimePicker1.Value.Date;
                    user.UserEmail = emailTextbox.Text;
                    user.UserPhone = phoneTextbox.Text;
                    user.UserRole = "User";
                    user.UserGender = gender;
                    db.Users.Add(user);
                    db.SaveChanges();
                    MessageBox.Show("Data inserted/updated successfully!");
                    viewData();
                    initialState();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            initialState();
        }

        private void maleRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void femaleRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }
    }
}
