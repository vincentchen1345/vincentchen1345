﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_OODB_Vincent
{
    public partial class buyLaptop : Form
    {
        databaseLaptopEntities db = new databaseLaptopEntities();
        public buyLaptop()
        {
            InitializeComponent();
            initialState();
            
        }

        public void initialState()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            label9.Text = "Rp. xxxx";
            numericUpDown1.Value = 0;
            
        }

        int subtotal = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            
            if (textBox1.Text=="")
            {
                MessageBox.Show("Please select data first!");
                return;
            }
            if(numericUpDown1.Value < 1)
            {
                MessageBox.Show("Quantity must be more than or equals to 1!");
                return;
            }
            int price1 = Decimal.ToInt32(numericUpDown1.Value)* Int32.Parse(textBox3.Text) ;
            dataGridView2.Rows.Add(textBox1.Text, textBox2.Text, textBox3.Text, numericUpDown1.Value, price1);
            subtotal = subtotal + price1;
            label9.Text = "Rp. " + subtotal.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string userID = Login.userID;
            int x = dataGridView2.Rows.Count;
            if(x==0)
            {
                MessageBox.Show("No laptop in cart!");
            }
            else
            {
                
                while(x>0)
                {
                    x--;
                    int counter = db.HeaderTransactions.Count() + 1;
                    string idNumber = counter.ToString("000");
                    string ID = "TR" + idNumber;
                    HeaderTransaction HT = new HeaderTransaction();
                    DetailTransaction DT = new DetailTransaction();
                    HT.TransactionID = ID;
                    DT.TransactionID = ID;
                    HT.UserID = userID;
                    DT.Quantity = Decimal.ToInt32(numericUpDown1.Value);
                    HT.TransactionDate = DateTime.Now.ToString("dd/MM/yyyy");
                    DT.LaptopID = dataGridView2.Rows[0].Cells[0].Value.ToString();
                    db.HeaderTransactions.Add(HT);
                    db.DetailTransactions.Add(DT);
                    db.SaveChanges();
                    dataGridView2.Rows.RemoveAt(0);
                }
                initialState();
                subtotal = 0;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(textBox4.Text=="")
            {
                MessageBox.Show("Please select data first!");
                return;
            }
            
            dataGridView2.Rows.RemoveAt(dataGridView2.CurrentCell.RowIndex);
            textBox4.Text = "";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            textBox1.Text = dataGridView1.Rows[index].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.Rows[index].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[index].Cells[6].Value.ToString();
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            textBox4.Text = dataGridView1.Rows[index].Cells[0].Value.ToString();
        }

        private void buyLaptop_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseLaptopDataSet.Laptop' table. You can move, or remove it, as needed.
            this.laptopTableAdapter.Fill(this.databaseLaptopDataSet.Laptop);

        }

        
    }
}
