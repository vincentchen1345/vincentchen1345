﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_OODB_Vincent
{
    public partial class manageLaptopBrand : Form
    {
        databaseLaptopEntities db = new databaseLaptopEntities();
        public manageLaptopBrand()
        {
            InitializeComponent();
            var query = (from x in db.LaptopBrands select x).ToList();
            dataGridView1.DataSource = query;
        }

        public void viewData()
        {
            var query = (from x in db.LaptopBrands select x).ToList();
            dataGridView1.DataSource = query;
        }

        private void InsertButton_Click(object sender, EventArgs e)
        {
            textBox2.Enabled = true;
            textBox1.Text = "";
            textBox2.Text = "";
            SaveButton.Enabled = true;
            CancelButton1.Enabled = true;
            InsertButton.Enabled = false;
            UpdateButton.Enabled = false;
            DeleteButton.Enabled = false;
            int counter = db.LaptopBrands.Count() + 1;
            string idNumber = counter.ToString("000");
            string ID = "BN" + idNumber;
            textBox1.Text = ID;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            textBox1.Text = dataGridView1.Rows[index].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.Rows[index].Cells[1].Value.ToString();
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                MessageBox.Show("Please select data first!");
                return;
            }
            else
            {
                textBox2.Enabled = true;
                SaveButton.Enabled = true;
                CancelButton1.Enabled = true;
                InsertButton.Enabled = false;
                UpdateButton.Enabled = false;
                DeleteButton.Enabled = false;
            }

        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            LaptopBrand laptop = new LaptopBrand();
            var brandName = (from x in db.LaptopBrands where x.LaptopBrandName.Equals(textBox2.Text) select x).FirstOrDefault();
            
            if (textBox2.Text.Length<2||textBox2.Text.Length>15)
            {
                MessageBox.Show("Brand Name length must be between 2-15 characters!”");
                return;
            }
            var check = (from y in db.LaptopBrands where y.LaptopBrandID.Equals(textBox1.Text) select y).FirstOrDefault();
            var checkx = (from z in db.LaptopBrands where z.LaptopBrandName.Equals(textBox2.Text) select z).FirstOrDefault();

            try
            {
                    var laptop1 = (from x in db.LaptopBrands where x.LaptopBrandID.Equals(textBox1.Text) select x).FirstOrDefault();
                    laptop1.LaptopBrandID = textBox1.Text;
                    laptop1.LaptopBrandName = textBox2.Text;
                    db.SaveChanges();
                    MessageBox.Show("Data inserted/updated successfully!");
                    viewData();
                    textBox2.Enabled = false;
                    SaveButton.Enabled = false;
                    CancelButton1.Enabled = false;
                    InsertButton.Enabled = true;
                    UpdateButton.Enabled = true;
                    DeleteButton.Enabled = true;
                    textBox1.Text = "";
                    textBox2.Text = "";

                }
                catch
                {
                    try
                    {
                        if (textBox2.Text == brandName.LaptopBrandName)
                        {
                            MessageBox.Show("Brand Name already exist!");
                            textBox2.Text = "";
                            return;
                        }
                    }
                    catch
                    {
                        laptop.LaptopBrandID = textBox1.Text;
                        laptop.LaptopBrandName = textBox2.Text;
                        db.LaptopBrands.Add(laptop);
                        db.SaveChanges();
                        textBox2.Enabled = false;
                        SaveButton.Enabled = false;
                        CancelButton1.Enabled = false;
                        InsertButton.Enabled = true;
                        UpdateButton.Enabled = true;
                        DeleteButton.Enabled = true;
                        textBox1.Text = "";
                        textBox2.Text = "";
                        MessageBox.Show("Data inserted/updated successfully!");
                        viewData();
                    }




                }
            }
        

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                MessageBox.Show("Please select data first!");
                return;
            }
            if (MessageBox.Show("Are you sure want to delete this data?", "Delete Data?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                var search = (from x in db.LaptopBrands where x.LaptopBrandID.Equals(textBox1.Text) select x).FirstOrDefault();
                db.LaptopBrands.Remove(search);
                db.SaveChanges();
                viewData();
                textBox1.Text = "";
                textBox2.Text = "";
            }
        }

        private void CancelButton1_Click(object sender, EventArgs e)
        {
            textBox2.Enabled = false;
            SaveButton.Enabled = false;
            CancelButton1.Enabled = false;
            InsertButton.Enabled = true;
            UpdateButton.Enabled = true;
            DeleteButton.Enabled = true;
        }

        private void manageLaptopBrand_Load(object sender, EventArgs e)
        {

        }
    }
}
