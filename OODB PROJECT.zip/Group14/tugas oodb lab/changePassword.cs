﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_OODB_Vincent
{
    public partial class changePassword : Form
    {
        databaseLaptopEntities db = new databaseLaptopEntities();
        public changePassword()
        {
            InitializeComponent();
        }

        private void changePassword_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var check = (from x in db.Users where x.UserName.Equals(Login.username) select x).FirstOrDefault();
            if(textBox1.Text=="")
            {
                MessageBox.Show("Old Password must be filled!");
                return;
            }
            if(check.UserPassword!=textBox1.Text)
            {
                MessageBox.Show("Old Password doesn’t match with the current password");
            }
            if(textBox2.Text=="")
            {
                MessageBox.Show("New Password must be filled!");
                return;
            }
            if(textBox2.Text.Length<5)
            {
                MessageBox.Show("New Password length must be 5 characters or more");
                return;
            }
            if(textBox3.Text!= textBox2.Text)
            {
                MessageBox.Show("Re-type Password doesn’t match with New Password!");
                return;
            }
            check.UserPassword = textBox2.Text;
            db.SaveChanges();
            MessageBox.Show("Successfully Change Password");
            this.Hide();
        }
    }
}
