﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_OODB_Vincent
{
    public partial class mainPageForStaff : Form
    {
        public mainPageForStaff()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            changePassword changePassword = new changePassword();
            changePassword.Show();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void laptopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            manageLaptop manageLaptop = new manageLaptop();
            manageLaptop.Show();
        }

        private void laptopBrandToolStripMenuItem_Click(object sender, EventArgs e)
        {
            manageLaptopBrand manageLB = new manageLaptopBrand();
            manageLB.Show();
        }

        private void userToolStripMenuItem_Click(object sender, EventArgs e)
        {
            manageUser manageU = new manageUser();
            manageU.Show();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            viewTransaction viewT = new viewTransaction();
            viewT.Show();
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
