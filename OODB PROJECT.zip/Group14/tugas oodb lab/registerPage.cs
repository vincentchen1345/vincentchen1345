﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_OODB_Vincent
{
    public partial class registerPage : Form
    {
        databaseLaptopEntities db = new databaseLaptopEntities();
        User user = new User();

        public registerPage()
        {
            InitializeComponent();
            dateTimePicker1.Value = DateTime.Today;
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (usernameTextbox.Text=="")
            {
                MessageBox.Show("Username must be filled!");
                return;
            }
            var check = (from x in db.Users where x.UserName.Equals(usernameTextbox.Text) select x).FirstOrDefault();
            try
            {
                if(usernameTextbox.Text == check.UserName)
                {
                    MessageBox.Show("Username already exist");
                }
            }
            catch
            {
                if (emailTextbox.Text == "")
                {
                    MessageBox.Show("Email must be filled!");
                    return;
                }
                if (!emailTextbox.Text.Contains('@') || !emailTextbox.Text.Contains('.'))
                {
                    MessageBox.Show("Email must contain ‘@’ and ‘.’");
                    return;
                }
                if (emailTextbox.Text.ToCharArray()[0] == '@' || emailTextbox.Text.ToCharArray()[0] == '.')
                {
                    MessageBox.Show("Email cannot start with ‘@’ or ‘.’");
                    return;
                }
                if (emailTextbox.Text.ToCharArray()[emailTextbox.TextLength-1] == '@' || emailTextbox.Text.ToCharArray()[emailTextbox.TextLength - 1] == '.')
                {
                    MessageBox.Show("Email cannot end with ‘@’ or ‘.’");
                    return;
                }
                int x = emailTextbox.Text.IndexOf('@');
                if (emailTextbox.Text.ToCharArray()[x + 1] == '.')
                {
                    MessageBox.Show("’@’ and ‘.’ cannot be placed beside each other");
                    return;
                }
                if(maleRadioButton.Checked!=true&&femaleRadioButton.Checked!=true)
                {
                    MessageBox.Show("Gender must be chosen!");
                    return;
                }
                if (dateTimePicker1.Value > DateTime.Today)
                {
                    MessageBox.Show("DOB cannot be greater than current date!");
                    return;
                }
                if (phoneTextbox.Text == "")
                {
                    MessageBox.Show("Phone must be filled!");
                    return;
                }
                if (!phoneTextbox.Text.All(char.IsDigit))
                {
                    MessageBox.Show("Phone must be numeric!");
                    return;
                }
                if (phoneTextbox.Text.Length < 12)
                {
                    MessageBox.Show("Phone must be 12 digits");
                    return;
                }
                if (richTextBox1.Text== "")
                {
                    MessageBox.Show("Address must be filled!");
                    return;
                }
                if (!richTextBox1.Text.Contains("Street"))
                {
                    MessageBox.Show("Address must contain ‘Street’");
                    return;
                }
                if(passwordTextbox.Text=="")
                {
                    MessageBox.Show("Password must be filled!");
                    return;
                }
                if(passwordTextbox.Text.Length<5)
                {
                    MessageBox.Show("Password length must be 5 characters or more");
                    return;
                }
                if(textBox5.Text!=passwordTextbox.Text)
                {
                    MessageBox.Show("Confirm Password must be the same with Password!");
                    return;
                }

                int counter = db.Users.Count() + 1;
                string idNumber = counter.ToString("000");
                string ID = "US" + idNumber;
                user.UserID = ID;
                user.UserName = usernameTextbox.Text;
                user.UserPassword = passwordTextbox.Text;
                user.UserAddress = richTextBox1.Text;
                user.UserDoB = dateTimePicker1.Value;
                user.UserEmail = emailTextbox.Text;
                user.UserPhone = phoneTextbox.Text;
                user.UserRole = "User";
                db.Users.Add(user);
                db.SaveChanges();
                MessageBox.Show("Success");

            }
        }

        private void maleRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            user.UserGender = "Male";
        }

        private void femaleRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            user.UserGender = "Femalie";
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }
    }
}
