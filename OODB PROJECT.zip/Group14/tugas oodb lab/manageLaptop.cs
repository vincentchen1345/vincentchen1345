﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_OODB_Vincent
{
    public partial class manageLaptop : Form
    {
        databaseLaptopEntities db = new databaseLaptopEntities();
        public manageLaptop()
        {
            InitializeComponent();
            viewData();

            comboBox1.DataSource = db.LaptopBrands.ToList();
            comboBox1.DisplayMember = "LaptopBrandName";
            comboBox1.ValueMember = "LaptopBrandID";
            comboBox1.SelectedValue = "";
        }

        public void viewData()
        {
            var query = (from x in db.Laptops select x).ToList();
            dataGridView1.DataSource = query;
        }

        

        private void InsertButton_Click(object sender, EventArgs e)
        {
            SaveButton.Enabled = true;
            CancelButton1.Enabled = true;
            InsertButton.Enabled = false;
            UpdateButton.Enabled = false;
            DeleteButton.Enabled = false;
            comboBox1.Enabled = true;
            LaptopName.Enabled = true;
            LaptopPrice.Enabled = true;
            LaptopSize.Enabled = true;
            LaptopVGA.Enabled = true;
            numericUpDown1.Enabled = true;
            int counter = db.Laptops.Count() + 1;
            string idNumber = counter.ToString("000");
            string ID = "LP" + idNumber;
            LaptopID.Text = ID;
            LaptopName.Text = "";
            LaptopPrice.Text = "";
            LaptopSize.Text = "";
            LaptopVGA.Text = "";
            numericUpDown1.Value = 0;
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            if (LaptopID.Text == "")
            {
                MessageBox.Show("Please select data first!");
                return;
            }
            else
            {
                SaveButton.Enabled = true;
                CancelButton1.Enabled = true;
                InsertButton.Enabled = false;
                UpdateButton.Enabled = false;
                DeleteButton.Enabled = false;
                comboBox1.Enabled = true;
                LaptopName.Enabled = true;
                LaptopPrice.Enabled = true;
                LaptopSize.Enabled = true;
                LaptopVGA.Enabled = true;
                numericUpDown1.Enabled = true;
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (LaptopID.Text == "")
            {
                MessageBox.Show("Please select data first!");
                return;
            }
            else
            {
                if (MessageBox.Show("Are you sure want to delete this data?", "Delete Data?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    var search = (from x in db.Laptops where x.LaptopID.Equals(LaptopID.Text) select x).FirstOrDefault();
                    db.Laptops.Remove(search);
                    db.SaveChanges();
                    viewData();
                }
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            

            if (LaptopName.Text== "")
            {
                MessageBox.Show("Laptop Name must be filled!");
                return;
            }
            
            if (comboBox1.Text == "")
            {
                 MessageBox.Show("Laptop Brand must be chosen!");
                 return;
            }

            if (LaptopSize.Text== "")
            {
                MessageBox.Show("Laptop Size must be filled!");
                return;
            }
                    
            if (!LaptopSize.Text.Contains(" inch"))
            {
                MessageBox.Show("Laptop Size must end with ‘inch’");
                return;
            }
                        
            if (LaptopVGA.Text== "")
            {
                MessageBox.Show("Laptop VGA must be filled!");
                return;
            }
                            
            if (Decimal.ToInt32(numericUpDown1.Value)< 2)
            {
                 MessageBox.Show("Laptop RAM must be 2 or more!");
                 return;
            }
                                
            if (LaptopPrice.Text== "")
            {
                 MessageBox.Show("Laptop Price must be filled!");
                 return;
            }
                                   
            if (!LaptopPrice.Text.All(char.IsDigit))
            {
                 MessageBox.Show("Laptop Price must be numeric!");
                 return;
            }
            var searchID = (from y in db.Laptops where y.LaptopID.Equals(LaptopID.Text) select y).FirstOrDefault();
            var searchBID = (from x in db.LaptopBrands where x.LaptopBrandID.Equals(comboBox1.SelectedValue.ToString()) select x).FirstOrDefault();

            try
            {
                if (LaptopID.Text == searchID.LaptopID.ToString())
                {
                    var check = (from x in db.Laptops where x.LaptopID.Equals(LaptopID.Text) select x).FirstOrDefault();
                    check.LaptopName = LaptopName.Text; ;
                    check.LaptopSize = LaptopSize.Text; ;
                    check.LaptopVGA = LaptopVGA.Text; ;
                    check.LaptopRAM = Decimal.ToInt32(numericUpDown1.Value).ToString();
                    check.LaptopPrice = Int32.Parse(LaptopPrice.Text);
                    check.LaptopBrandID = searchBID.LaptopBrandID;
                    db.SaveChanges();
                    MessageBox.Show("Data inserted/updated successfully!");
                    viewData();
                    SaveButton.Enabled = false;
                    CancelButton1.Enabled = false;
                    InsertButton.Enabled = true;
                    UpdateButton.Enabled = true;
                    DeleteButton.Enabled = true;
                    comboBox1.Enabled = false;
                    LaptopName.Enabled = false;
                    LaptopPrice.Enabled = false;
                    LaptopSize.Enabled = false;
                    LaptopVGA.Enabled = false;
                    numericUpDown1.Enabled = false;
                    comboBox1.Text = "";
                    LaptopID.Text = "";
                    LaptopName.Text = "";
                    LaptopSize.Text = "";
                    LaptopVGA.Text = "";
                    LaptopPrice.Text = "";
                    numericUpDown1.Value = 0;
                }
            }
            catch
            {
                Laptop laptop = new Laptop();
                laptop.LaptopID = LaptopID.Text;
                laptop.LaptopName = LaptopName.Text; ;
                laptop.LaptopSize = LaptopSize.Text; ;
                laptop.LaptopVGA = LaptopVGA.Text; ;
                laptop.LaptopRAM = Decimal.ToInt32(numericUpDown1.Value).ToString();
                laptop.LaptopPrice = Int32.Parse(LaptopPrice.Text);
                laptop.LaptopBrandID = searchBID.LaptopBrandID;
                db.Laptops.Add(laptop);
                db.SaveChanges();
                MessageBox.Show("Data inserted/updated successfully!");
                viewData();
                SaveButton.Enabled = false;
                CancelButton1.Enabled = false;
                InsertButton.Enabled = true;
                UpdateButton.Enabled = true;
                DeleteButton.Enabled = true;
                comboBox1.Enabled = false;
                LaptopName.Enabled = false;
                LaptopPrice.Enabled = false;
                LaptopSize.Enabled = false;
                LaptopVGA.Enabled = false;
                numericUpDown1.Enabled = false;
                comboBox1.Text = "";
                LaptopID.Text = "";
                LaptopName.Text = "";
                LaptopSize.Text = "";
                LaptopVGA.Text = "";
                LaptopPrice.Text = "";
                numericUpDown1.Value = 0;
            }


        }






        private void CancelButton1_Click(object sender, EventArgs e)
        {
            SaveButton.Enabled = false;
            CancelButton1.Enabled = false;
            InsertButton.Enabled = true;
            UpdateButton.Enabled = true;
            DeleteButton.Enabled = true;
            comboBox1.Enabled = false;
            LaptopName.Enabled = false;
            LaptopPrice.Enabled = false;
            LaptopSize.Enabled = false;
            LaptopVGA.Enabled = false;
            numericUpDown1.Enabled = false;
            comboBox1.Text = "";
            LaptopID.Text = "";
            LaptopName.Text = "";
            LaptopSize.Text = "";
            LaptopVGA.Text = "";
            LaptopPrice.Text = "";
            numericUpDown1.Value = 0;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            LaptopID.Text = dataGridView1.Rows[index].Cells[0].Value.ToString();
            LaptopSize.Text = dataGridView1.Rows[index].Cells[3].Value.ToString();
            LaptopName.Text = dataGridView1.Rows[index].Cells[2].Value.ToString();
            LaptopVGA.Text = dataGridView1.Rows[index].Cells[4].Value.ToString();
            numericUpDown1.Value = Int32.Parse(dataGridView1.Rows[index].Cells[5].Value.ToString());
            LaptopPrice.Text = dataGridView1.Rows[index].Cells[6].Value.ToString();
            comboBox1.SelectedValue = dataGridView1.Rows[index].Cells[1].Value.ToString();
        }
        
    }
}
